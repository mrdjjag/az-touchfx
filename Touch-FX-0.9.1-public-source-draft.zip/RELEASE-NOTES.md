# Touch FX 0.9.1

STEMS and Drum Roll now fit the compact 4 DECK view with deck information shown or hidden. This update also includes selected-stem Echo and Gate, stronger STEMS tint in Colour and Transparent modes, and a soft reminder around attenuated STEMS labels.
