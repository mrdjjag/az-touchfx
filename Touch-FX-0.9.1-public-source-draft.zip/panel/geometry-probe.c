/* SPDX-License-Identifier: GPL-3.0-only */
#define _GNU_SOURCE
#include <sys/uio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include "auto_geometry.h"
static int read_native(void *opaque,uintptr_t addr,void *out,size_t n){pid_t pid=*(pid_t*)opaque;struct iovec l={out,n},r={(void*)addr,n};return process_vm_readv(pid,&l,1,&r,1,0)==(ssize_t)n;}
int main(int argc,char **argv){if(argc!=3)return 2;pid_t pid=(pid_t)strtol(argv[1],0,10);uintptr_t slot=strtoull(argv[2],0,0);struct geometry g;if(!geometry_measure(read_native,&pid,slot,&g)){puts("UNKNOWN: no geometry published");return 1;}printf("mode=%d left=%d bottom=%d\n",g.mode,g.left,g.bottom);return 0;}
