See root README.md. Requires matching custom core and audio for AZ-MODS 1.2.8.
