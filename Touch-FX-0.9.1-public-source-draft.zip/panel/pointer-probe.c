#include <linux/input.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <unistd.h>
int main(void){int fd=open("/dev/input/event0",O_RDONLY|O_NONBLOCK);char name[80]={0};struct input_absinfo x,y;
 if(fd<0||ioctl(fd,EVIOCGNAME(sizeof name),name)<0||ioctl(fd,EVIOCGABS(ABS_MT_POSITION_X),&x)<0||ioctl(fd,EVIOCGABS(ABS_MT_POSITION_Y),&y)<0)return 1;
 int ids[2]={ABS_MT_TRACKING_ID,-1};int ok=ioctl(fd,EVIOCGMTSLOTS(sizeof ids),ids);
 printf("Read-only input OK: %s X=%d..%d Y=%d..%d primary-slot-query=%s pressed=%d\n",name,x.minimum,x.maximum,y.minimum,y.maximum,ok>=0?"OK":"unavailable",ids[1]>=0);close(fd);return 0;}
