#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdatomic.h>
#include "src/azstem/stem_fx.h"
#define NDECK 4
typedef struct {float *stem[4];long stem_frames;_Atomic unsigned ctrl;_Atomic long stem_off;} deck_stems;
typedef struct {_Atomic unsigned seq;_Atomic double beat_src;_Atomic long long anchor_src;_Atomic int valid;} drum_grid;
static deck_stems g_dk[NDECK];static drum_grid g_drum_grid[NDECK];
static _Atomic unsigned g_deck_trackgen[NDECK];static _Atomic long long g_play_obs[NDECK];
static int level=1000;int azstem_stem_fx_level(void){return level;}
#include "src/azstem/stem_target_fx.c"
static float source[4][8192];
static void reset(int d){
 target_clear(&g_target_fx[d]);atomic_store(&g_target_screen[d],0);atomic_store(&g_target_age[d],0);
 atomic_store(&g_play_obs[d],100);atomic_store(&g_deck_trackgen[d],1);
 atomic_store(&g_drum_grid[d].valid,1);atomic_store(&g_drum_grid[d].beat_src,100);atomic_store(&g_drum_grid[d].anchor_src,0);
 g_dk[d].stem_frames=4096;atomic_store(&g_dk[d].ctrl,0x8f);atomic_store(&g_dk[d].stem_off,0);
 for(int k=0;k<4;k++)g_dk[d].stem[k]=source[k];
}
int main(void){
 for(int k=0;k<4;k++)for(int i=0;i<8192;i++)source[k][i]=.1f*(k+1);
 float original[sizeof source/sizeof(float)];memcpy(original,source,sizeof source);
 int modes[]={2,4};unsigned cases=0;
 for(int d=0;d<4;d++)for(unsigned mask=1;mask<8;mask++)for(int m=0;m<2;m++){
  reset(d);assert(azstem_target_fx_test(d,1,1,4,modes[m],800,(int)(mask|8))); /* drums bit rejected */
  vocal_echo_page p;assert(vocal_echo_page_prepare(d,100,228,&p));assert(p.mask==mask&&p.mode==modes[m]);
  for(int k=0;k<4;k++){
   float dry=source[k][600],l=dry,r=dry;vocal_echo_page_add(&p,k,source[k],4096,300,&l,&r);
   if(mask&(1u<<k)){assert(modes[m]==2?l>dry:l<dry);assert(l==r&&isfinite(l));}
   else assert(l==dry&&r==dry);
   float l2=dry,r2=dry;vocal_echo_page_add(&p,k,source[k],4096,300,&l2,&r2);assert(l2==l&&r2==r);
  }
  atomic_store(&g_play_obs[d],350);assert(azstem_target_fx_test(d,1,0,4,modes[m],800,(int)mask));
  assert(vocal_echo_page_prepare(d,400,528,&p));assert(p.p.end==400);
  if(modes[m]==4)assert(!vocal_echo_page_prepare(d,800,928,&p));
  else assert(vocal_echo_page_prepare(d,800,928,&p));
  azstem_target_fx_test(d,0,0,0,2,0,0);assert(!vocal_echo_page_prepare(d,800,928,&p));
  assert(azstem_target_fx_test(d,1,0,4,modes[m],800,(int)mask));assert(!vocal_echo_page_prepare(d,900,1028,&p)); /* no stale restart */
  cases++;
 }
 assert(!memcmp(original,source,sizeof source));
 reset(0);assert(azstem_target_fx_test(0,1,1,4,4,1000,1));vocal_echo_page p;assert(vocal_echo_page_prepare(0,100,228,&p));
 atomic_store(&g_play_obs[0],300);assert(azstem_target_fx_test(0,1,1,4,4,0,1));assert(vocal_echo_page_prepare(0,300,428,&p));
 float l=1,r=1;vocal_echo_page_add(&p,0,source[0],4096,300,&l,&r);assert(l<.01f);l=r=1;vocal_echo_page_add(&p,0,source[0],4096,428,&l,&r);assert(l==1&&r==1);
 atomic_store(&g_deck_trackgen[0],2);assert(!vocal_echo_page_prepare(0,500,628,&p));
 reset(1);assert(azstem_target_fx_test(1,1,1,4,2,500,2));vocal_echo_test_tick(1,128);for(int i=0;i<400;i++)vocal_echo_test_tick(1,128);assert(!vocal_echo_page_prepare(1,500,628,&p));
 reset(2);atomic_store(&g_drum_grid[2].valid,0);assert(!azstem_target_fx_test(2,1,1,4,4,500,7));
 assert(!azstem_target_fx_test(-1,1,1,4,4,500,1));assert(!azstem_target_fx_test(2,1,1,4,0,500,7));
 for(int i=0;i<50000;i++){
  float gain=target_gate_gain(i,100,40000,-1000,22050,.8f);assert(isfinite(gain)&&gain>=.19999f&&gain<=1);
  if(i>40256)assert(gain==1);
 }
 assert(mrdjjag_target_fx_abi()==1);
 printf("PASS %u target scenarios: four decks, all seven masks, Echo/Gate, drums exclusion, untouched PCM, deterministic reads, release/closing, no stale restart, Gate transition ramps, track/lease/grid guards.\n",cases);
}
