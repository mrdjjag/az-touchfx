/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef TOUCHFX_TARGET_GATE_SOURCE_H
#define TOUCHFX_TARGET_GATE_SOURCE_H
#include <math.h>
#include <stdint.h>
static inline float target_smooth(float x){if(x<=0)return 0;if(x>=1)return 1;return x*x*(3.f-2.f*x);}
/* Source-time gain: deterministic on repeated/out-of-order reads. Smooth gate
 * edges plus bounded start/release ramps, without a mutable audio history. */
static inline float target_gate_gain(int64_t i,int64_t begin,int64_t end,int64_t anchor,int delay,float depth){
 if(i<begin||delay<1||depth<=0)return 1.f;
 if(depth>1)depth=1;
 float envelope=target_smooth((float)(i-begin+1)/128.f);
 if(end>=0&&i>=end)envelope*=1.f-target_smooth((float)(i-end+1)/256.f);
 if(envelope<=0)return 1.f;
 int64_t rem=(i-anchor)%delay;if(rem<0)rem+=delay;
 double phase=(double)rem/delay,edge=fmin(.06,128.0/delay),open=0;
 if(phase<.5){open=fmin(phase/edge,(.5-phase)/edge);if(open>1)open=1;open=open*open*(3.-2.*open);}
 return 1.f-depth*envelope*(1.f-(float)open);
}
#endif
